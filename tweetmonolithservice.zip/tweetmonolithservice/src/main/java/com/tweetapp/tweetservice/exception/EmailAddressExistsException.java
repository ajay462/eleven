package com.tweetapp.tweetservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Email Address is already registered. Please check again.")

public class EmailAddressExistsException extends Exception {

    public EmailAddressExistsException() {
        super();
    }

}
