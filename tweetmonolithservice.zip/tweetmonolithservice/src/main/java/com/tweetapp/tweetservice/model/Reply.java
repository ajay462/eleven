package com.tweetapp.tweetservice.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class Reply {

    private String userName;
    private String comment;
    private String repliedOn;

    public Reply() {
		super();
	}

	public Reply(String userName, String comment, String repliedOn) {
        super();
        this.userName = userName;
        this.comment = comment;
        this.repliedOn = repliedOn;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getRepliedOn() {
        return repliedOn;
    }

    public void setRepliedOn(String repliedOn) {
        this.repliedOn = repliedOn;
    }

    @Override
    public String toString() {
        return "Reply [userName=" + userName + ", comment=" + comment + ", repliedOn=" + repliedOn + "]";
    }

}
