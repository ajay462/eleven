package com.tweetapp.tweetservice.service;

import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import com.tweetapp.tweetservice.exception.IncorrectPasswordException;
import com.tweetapp.tweetservice.exception.UserNotFoundException;
import com.tweetapp.tweetservice.model.AppUser;
import com.tweetapp.tweetservice.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class AuthenticationService implements UserDetailsService {

    @Autowired
    UserRepository userRepository;

    public AuthenticationService(UserRepository userRepository) {
        super();
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser user = userRepository.findByUserName(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        } else {
            List<SimpleGrantedAuthority> authorities = Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
            return new User(user.getUserName(), user.getPassword(), authorities);
        }
    }

    public String getUser(String authHeader) throws Exception {
        byte[] codes = Base64.getDecoder().decode(authHeader);
        String userData = new String(codes);
        String username = userData.split(":")[0];
        AppUser user = userRepository.findByUserName(username);
        if (user == null) {
            throw new UserNotFoundException();
        } else {
            if (passwordencoder().matches(userData.split(":")[1], user.getPassword())) {
                return generateJwt(username);
            } else {
                throw new IncorrectPasswordException();
            }
        }
    }

    public String generateJwt(String username) {
        AppUser user = userRepository.findByUserName(username);
        JwtBuilder builder = Jwts.builder();
        builder.setSubject(username);
        builder.setIssuedAt(new Date());
        builder.setExpiration(new Date((new Date()).getTime() + 1200000));
        builder.signWith(SignatureAlgorithm.HS256, "A4FA3FB796A06059E5B0478E82A5685144D4BC80F4412D3891D33619E05A8839");
        if (user != null) {
            builder.claim("userData", user);
        }
        String token = builder.compact();
        return token;
    }

    @Bean()
    public PasswordEncoder passwordencoder() {
        return new BCryptPasswordEncoder(12);
    }

}
