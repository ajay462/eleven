package com.tweetapp.tweetservice.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConvertedJson;

@DynamoDBTable(tableName = "tweet")
public class TweetDoc {

    @DynamoDBHashKey
    private String tweetId;
	@DynamoDBAttribute
    private String userName;
	@DynamoDBTypeConvertedJson
	@DynamoDBAttribute
    private Tweet tweet;

    public TweetDoc() {
		super();
	}

	public TweetDoc(String tweetId, String userName, Tweet tweet) {
        super();
        this.tweetId = tweetId;
        this.userName = userName;
        this.tweet = tweet;
    }

    public String getTweetId() {
        return tweetId;
    }

    public void setTweetId(String tweetId) {
        this.tweetId = tweetId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Tweet getTweet() {
        return tweet;
    }

    public void setTweet(Tweet tweet) {
        this.tweet = tweet;
    }

    @Override
    public String toString() {
        return "TweetDoc [tweetId=" + tweetId + ", userName=" + userName + ", tweet=" + tweet + "]";
    }

}
