package com.tweetapp.tweetservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.tweetapp.tweetservice.model.AppUser;
import com.tweetapp.tweetservice.exception.DataMismatchException;
import com.tweetapp.tweetservice.exception.EmailAddressExistsException;
import com.tweetapp.tweetservice.exception.MobileNumberExistsException;
import com.tweetapp.tweetservice.exception.UserAlreadyExistsException;
import com.tweetapp.tweetservice.exception.UserNotFoundException;
import com.tweetapp.tweetservice.model.PasswordObject;
import com.tweetapp.tweetservice.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        super();
        this.userRepository = userRepository;
    }

    public AppUser getUser(String userName) throws UserNotFoundException {
        AppUser user = userRepository.findByUserName(userName);
        if (user == null) {
            throw new UserNotFoundException();
        } else {
            return user;
        }
    }

    public void createUser(AppUser user)
            throws UserAlreadyExistsException, EmailAddressExistsException, MobileNumberExistsException {
        if (userRepository.findByUserName(user.getUserName()) != null) {
            throw new UserAlreadyExistsException();
        } else if (userRepository.findByEmailAddress(user.getEmailAddress()) != null) {
            throw new EmailAddressExistsException();
        } else if (userRepository.findByMobileNumber(user.getMobileNumber()) != null) {
            throw new MobileNumberExistsException();
        } else {
            user.setPassword(passwordEncoder().encode(user.getPassword()));
            userRepository.save(user);
        }
    }

    public void updatePassword(PasswordObject passwordObject, String type)
            throws UserNotFoundException, DataMismatchException {
        AppUser user = userRepository.findByUserName(passwordObject.getUserName());
        if (user == null) {
            throw new UserNotFoundException();
        } else {
            if (type.equalsIgnoreCase("reset")) {
                if (passwordEncoder().matches(passwordObject.getOldPassword(), user.getPassword())) {
                    user.setPassword(passwordEncoder().encode(passwordObject.getNewPassword()));
                    userRepository.save(user);
                } else {
                    throw new DataMismatchException();
                }
            } else if (type.equalsIgnoreCase("forgot")) {
                if (user.getDateOfBirth().equals(passwordObject.getDateOfBirth())) {
                    user.setPassword(passwordEncoder().encode(passwordObject.getNewPassword()));
                    userRepository.save(user);
                } else {
                    throw new DataMismatchException();
                }
            }
        }
    }

    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

}
