package com.tweetapp.tweetservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Username is already taken. Please choose another.")

public class UserAlreadyExistsException extends Exception {

    public UserAlreadyExistsException() {
        super();
    }

}
