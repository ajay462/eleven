package com.tweetapp.tweetservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweetservice.model.Reply;
import com.tweetapp.tweetservice.model.TweetDoc;
import com.tweetapp.tweetservice.service.TweetService;

@RestController
@RequestMapping("/api/tweets")
public class TweetController {

    @Autowired
    TweetService tweetService;

    @PostMapping("/post")
    public void postTweet(@RequestBody TweetDoc tweetDoc) {
        tweetService.postTweet(tweetDoc);
    }

    @GetMapping("/fetch/all")
    public List<TweetDoc> fetchAllTweets() {
        return tweetService.fetchAllTweets();
    }

    @GetMapping("/fetch/{userName}")
    public List<TweetDoc> fetchByUser(@PathVariable String userName) {
        return tweetService.fetchByUser(userName);
    }

    @GetMapping("/like/{tweetId}/{userName}")
    public void likeTweet(@PathVariable String tweetId, @PathVariable String userName) {
        tweetService.likeTweet(tweetId, userName);
    }

    @PostMapping("/reply/{tweetId}")
    public void replyTweet(@RequestBody Reply reply, @PathVariable String tweetId) {
        tweetService.replyTweet(tweetId, reply);
    }

}
