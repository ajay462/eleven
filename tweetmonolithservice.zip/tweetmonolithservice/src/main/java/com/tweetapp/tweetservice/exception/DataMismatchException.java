package com.tweetapp.tweetservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Input data does not match with our records. Please try again with valid input.")

public class DataMismatchException extends Exception {

    public DataMismatchException() {
        super();
    }

}
