package com.tweetapp.tweetservice.model;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConvertedJson;

@DynamoDBDocument
public class Tweet {

    private String message;
    private String tag;
    private String postedOn;
    private List<String> likedUsers;
    @DynamoDBTypeConvertedJson
    private List<Reply> replies;

    public Tweet() {
		super();
	}

	public Tweet(String message, String tag, String postedOn, List<String> likedUsers, List<Reply> replies) {
        super();
        this.message = message;
        this.tag = tag;
        this.postedOn = postedOn;
        this.likedUsers = likedUsers;
        this.replies = replies;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getPostedOn() {
        return postedOn;
    }

    public void setPostedOn(String postedOn) {
        this.postedOn = postedOn;
    }

    public List<String> getLikedUsers() {
        return likedUsers;
    }

    public void setLikedUsers(List<String> likedUsers) {
        this.likedUsers = likedUsers;
    }

    public List<Reply> getReplies() {
        return replies;
    }

    public void setReplies(List<Reply> replies) {
        this.replies = replies;
    }

    @Override
    public String toString() {
        return "Tweet [message=" + message + ", tag=" + tag + ", postedOn=" + postedOn + ", likedUsers=" + likedUsers
                + ", replies=" + replies + "]";
    }

}
