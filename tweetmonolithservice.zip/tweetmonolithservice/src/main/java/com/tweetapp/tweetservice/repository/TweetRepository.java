package com.tweetapp.tweetservice.repository;

import java.util.List;

import com.tweetapp.tweetservice.model.TweetDoc;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;

@EnableScan
public interface TweetRepository extends CrudRepository<TweetDoc, String> {

    TweetDoc findByTweetId(String tweetId);

    List<TweetDoc> findByUserName(String userName);

}