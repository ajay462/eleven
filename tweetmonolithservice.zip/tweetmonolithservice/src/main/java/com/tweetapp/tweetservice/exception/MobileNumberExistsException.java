package com.tweetapp.tweetservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Mobile Number is already registered. Please check again.")

public class MobileNumberExistsException extends Exception {

    public MobileNumberExistsException() {
        super();
    }

}
