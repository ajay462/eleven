package com.tweetapp.tweetservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweetservice.model.AppUser;
import com.tweetapp.tweetservice.exception.DataMismatchException;
import com.tweetapp.tweetservice.exception.EmailAddressExistsException;
import com.tweetapp.tweetservice.exception.MobileNumberExistsException;
import com.tweetapp.tweetservice.exception.UserAlreadyExistsException;
import com.tweetapp.tweetservice.exception.UserNotFoundException;
import com.tweetapp.tweetservice.model.PasswordObject;
import com.tweetapp.tweetservice.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping("fetch/{userName}")
    public AppUser getUser(@PathVariable String userName) throws UserNotFoundException {
        return userService.getUser(userName);
    }

    @PostMapping("/create")
    public void createUser(@RequestBody AppUser user)
            throws UserAlreadyExistsException, EmailAddressExistsException, MobileNumberExistsException {
        userService.createUser(user);
    }

    @PostMapping("/password/{type}")
    public void updatePassword(@RequestBody PasswordObject passwordObject, @PathVariable String type)
            throws UserNotFoundException, DataMismatchException {
        userService.updatePassword(passwordObject, type);
    }

}
