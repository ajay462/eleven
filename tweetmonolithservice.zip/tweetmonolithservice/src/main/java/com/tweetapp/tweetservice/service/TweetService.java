package com.tweetapp.tweetservice.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.tweetservice.model.Reply;
import com.tweetapp.tweetservice.model.TweetDoc;
import com.tweetapp.tweetservice.repository.TweetRepository;

@Service
public class TweetService {

    @Autowired
    TweetRepository tweetRepository;

    public TweetService(TweetRepository tweetRepository) {
        super();
        this.tweetRepository = tweetRepository;
    }

    public void postTweet(TweetDoc tweetDoc) {
        tweetRepository.save(tweetDoc);
    }

    public List<TweetDoc> fetchAllTweets() {
    	List<TweetDoc> tweets = (List<TweetDoc>) tweetRepository.findAll();
    	List<TweetDoc> tweetList = new ArrayList<TweetDoc>(tweets);
    	Comparator<TweetDoc> compareByPostedOn = (TweetDoc o1, TweetDoc o2) -> o2.getTweet().getPostedOn().compareTo(o1.getTweet().getPostedOn());
    	Collections.sort(tweetList, compareByPostedOn);
    	return tweetList;
    }

    public List<TweetDoc> fetchByUser(String userName) {
        List<TweetDoc> tweetList = new ArrayList<TweetDoc>(tweetRepository.findByUserName(userName));
    	Comparator<TweetDoc> compareByPostedOn = (TweetDoc o1, TweetDoc o2) -> o2.getTweet().getPostedOn().compareTo(o1.getTweet().getPostedOn());
    	Collections.sort(tweetList, compareByPostedOn);
    	return tweetList;
    }

    public void likeTweet(String tweetId, String userName) {
        TweetDoc tweetDoc = tweetRepository.findByTweetId(tweetId);
        if (tweetDoc.getTweet().getLikedUsers().contains(userName)) {
            tweetDoc.getTweet().getLikedUsers().remove(userName);
        } else {
            tweetDoc.getTweet().getLikedUsers().add(userName);
        }
        tweetRepository.save(tweetDoc);
    }

    public void replyTweet(String tweetId, Reply reply) {
        TweetDoc tweetDoc = tweetRepository.findByTweetId(tweetId);
        tweetDoc.getTweet().getReplies().add(reply);
        tweetRepository.save(tweetDoc);
    }

}
