package com.tweetapp.tweetservice.repository;

import com.tweetapp.tweetservice.model.AppUser;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;

@EnableScan
public interface UserRepository extends CrudRepository<AppUser, String> {

    AppUser findByUserName(String userName);

    AppUser findByEmailAddress(String emailAddress);

    AppUser findByMobileNumber(String mobileNumber);

}
