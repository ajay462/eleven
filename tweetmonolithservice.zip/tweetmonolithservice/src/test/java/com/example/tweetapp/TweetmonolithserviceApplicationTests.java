package com.example.tweetapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
class TweetmonolithserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
