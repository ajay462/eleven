import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
  }
  updated=false;

  detailsSaved = true;
  
  onSubmit(changeDetailsForm: NgForm) {

    this.userService.modifyPassword(changeDetailsForm.value).subscribe();
    this.updated = true;

  }
}
