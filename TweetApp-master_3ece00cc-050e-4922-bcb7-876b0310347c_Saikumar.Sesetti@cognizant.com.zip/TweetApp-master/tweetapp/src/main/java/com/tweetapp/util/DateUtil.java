package com.tweetapp.util;

public class DateUtil {

	public static String getCurrentTime() {
		return String.valueOf(System.currentTimeMillis());
	}
}