package com.tweetapp;


/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */

    public void shouldAnswerWithTrue()
    {

    }
}
