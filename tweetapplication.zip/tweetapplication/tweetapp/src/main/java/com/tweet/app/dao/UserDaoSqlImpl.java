package com.tweet.app.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tweet.app.constants.Constants;
import com.tweet.app.model.User;
import com.tweet.app.util.DbHandler;

public class UserDaoSqlImpl {

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	public List<User> getAllUsers() {
		connection = DbHandler.getConnection();
		List<User> usersList = new ArrayList<>();
		try {
			preparedStatement = connection.prepareStatement(Constants.GET_ALL_USERS);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				do {
					String email = resultSet.getString("us_email");
					User user = new User();
					user.setEmail(email);
					usersList.add(user);
				} while (resultSet.next());
			} else {
				System.err.println("No tweets found");
			}
			return usersList;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection is not closed properly");
			}
		}
		return usersList;
	}
	
	public User getUser(String username) throws Exception {
		connection = DbHandler.getConnection();
		User user = new User();
		try {
			preparedStatement = connection.prepareStatement(Constants.GET_USER);
			preparedStatement.setString(1, username);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
					String email = resultSet.getString("us_email");
					String password = resultSet.getString("us_password");
					user.setEmail(email);
					user.setPassword(password);
			} else {
				throw new Exception();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection is not closed properly");
			}
		}
		return user;
	}

	public void saveUser(User user) throws Exception {
		connection = DbHandler.getConnection();
		try {
			preparedStatement = connection.prepareStatement(Constants.SAVE_USER);
			preparedStatement.setString(1, user.getFirstname());
			preparedStatement.setString(2, user.getLastname());
			preparedStatement.setString(3, user.getGender());
			preparedStatement.setDate(4, new Date(user.getDob().getTime()));
			preparedStatement.setString(5, user.getEmail());
			preparedStatement.setString(6, user.getPassword());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection is not closed properly");
			}
		}	
	}
	
	public boolean savePassword(String newPwd, String username) throws Exception {
		connection = DbHandler.getConnection();
		try {
			preparedStatement = connection.prepareStatement(Constants.UPDATE_USER);
			preparedStatement.setString(1, newPwd);
			preparedStatement.setString(2, username);
			preparedStatement.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection is not closed properly");
			}
		}
		return true;
	}

	public void closedb() throws SQLException {

		if (resultSet != null) {
			resultSet.close();
		}
		if (preparedStatement != null) {
			preparedStatement.close();
		}
		if (connection != null) {
			connection.close();
		}
	}

}
