package com.tweet.app.service;

import java.util.List;

import com.tweet.app.model.Tweet;
import com.tweet.app.dao.TweetDaoSqlImpl;
import com.tweet.app.dao.UserDaoSqlImpl;

public class TweetService {

	TweetDaoSqlImpl tweetDao = new TweetDaoSqlImpl();
	UserDaoSqlImpl userDao = new UserDaoSqlImpl();
	
	public boolean saveTweet(String message, String username) throws Exception { 
		tweetDao.savePost(message, username);
		return true;
	}
	
	
	public List<Tweet> getUsertweets(String username) throws Exception{
		return tweetDao.getPostsByUser(username);
	}
	
	public List<Tweet> getAlltweets(){
		return tweetDao.getPosts();
	}
	
}