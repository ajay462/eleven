package com.tweet.app.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.tweet.app.constants.Constants;

public class DateUtil {
	public static Date convertToDate(String date) {
		Date parsedDate = null;
		try {
			SimpleDateFormat dateFormate = new SimpleDateFormat(Constants.DOB_FORMAT);
			dateFormate.setLenient(false);
			parsedDate = dateFormate.parse(date);
		} catch (ParseException parseException) {
			System.out.println("invalid Date format... please enter the DateOfBirth "+Constants.DOB_FORMAT +" format");
		}
		return parsedDate;
	}
}