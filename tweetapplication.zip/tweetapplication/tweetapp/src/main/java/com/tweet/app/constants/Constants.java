package com.tweet.app.constants;

public class Constants {

	public static final String DOB_FORMAT = "yyyy/MM/dd";
	
	public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String URL = "jdbc:mysql://localhost:3306/tweetApp";
	public static final String SQL_USER = "root";
	public static final String SQL_PASSWORD = "root";
	
	public static final String GET_ALL_TWEETS = "SELECT po_message FROM post ";
	public static final String GET_USER_TWEETS = "SELECT po_message FROM post WHERE us_email = ? ";	
	public static final String SAVE_TWEET = "INSERT INTO post(po_message,us_email)values(?,?)";

	public static final String SAVE_USER = "INSERT INTO user (`us_first_name`, `us_last_name`, `us_gender`, `us_dob`, `us_email`, `us_password`)  VALUES (?,?,?,?,?,?)";
	public static final String GET_USER = "SELECT us_email, us_password from user where us_email = ?";	
	public static final String UPDATE_USER = "UPDATE user SET us_password = ? WHERE us_email = ?"; 
	public static final String GET_ALL_USERS = "SELECT us_email FROM user ";		

}