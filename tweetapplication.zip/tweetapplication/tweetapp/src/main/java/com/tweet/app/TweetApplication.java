package com.tweet.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.tweet.app.constants.Constants;
import com.tweet.app.model.Tweet;
import com.tweet.app.model.User;
import com.tweet.app.service.TweetService;
import com.tweet.app.service.UserService;

public class TweetApplication 
{
	static UserService userService = new UserService();
	static TweetService tweetService = new TweetService();
	static boolean isLogin;
	static boolean isExit = true;
	
	public static void main(String[] args) {
		
		
		String username = null;
		isLogin = false;
		
		while (isExit) {
			
			if(!isLogin) {
				
				System.out.println("Select Choice :  \n 1. Login \n 2.Register \n 3.Forgot Password");
				System.out.println("Press any other key to terminate TweetApp..");
			}
			System.out.println("elsewhere " + isLogin +" "+ username);
			
			BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
			String choice;
			try {
				choice = sc.readLine().trim();
				switch (choice) {
				case "1": {
					if (isLogin) {
						System.err.println("User already Logged in...");
					} else if (!isLogin) {
						String email = null;
						System.out.println("Enter email");
						email = sc.readLine().trim();
						System.out.println("Enter password");
						String password = sc.readLine();
						try {
							if (email != null && userService.isValidEmail(email) && userService.validateUser(email, password)) {
								username = email;
								System.out.println(isLogin);
								isLogin = true;
								System.out.println("login successfull");
								afterLogin(username, password, isLogin);								
								
							} else if(!userService.isValidEmail(email)) {
								System.out.println("Invalid Email/password");
							}else {
								System.err.println("incorrect credentials");
							}
						} catch (Exception e) {
							System.err.println("User not found...! Please signUp before logging in....");
						}
					}
					break;
				}

				case "2": {
					if (!isLogin) {
						System.out.println("New User Registration form...");
						System.out.println("Enter firstname");
						String fname = sc.readLine().trim();
						System.out.println("Enter lastname");
						String lname = sc.readLine().trim();
						System.out.println("Enter gender (Male/Female)");
						String gender = sc.readLine().trim();
						System.out.println("Enter DateOfBirth " + Constants.DOB_FORMAT);
						String dob = sc.readLine().trim();
						System.out.println("Enter email");
						String email = sc.readLine().trim();
						System.out.println("Enter password");
						String pwd = sc.readLine();
						boolean validFirstName = userService.isValidName(fname);
						boolean validLastName = userService.isValidName(lname);
						boolean validGender = false;
						if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female"))
							validGender = true;
						boolean validDOB = userService.isValidDateOfBirth(dob);
						boolean validEmail = userService.isValidEmail(email);
						boolean validPassword = userService.isValidPassword(pwd);
						try {
							if (validFirstName && validLastName && validEmail && validPassword && validDOB && validGender) {
								userService.saveUser(fname, lname, gender, dob, email, pwd);
								System.out.println("User details Saved Successfully");
							}
							if (!validFirstName) {
								System.out.println("Invalid First Name");
							}
							if (!validLastName) {
								System.out.println("Invalid Last Name");
							}
							if (!validEmail) {
								System.out.println("Invalid Email");
							}
							if (!validDOB) {
								System.out.println("Invalid Date Of Birth. Please enter in yyyy/mm/dd format.");
							}
							if (!validPassword) {
								System.out.println(
										"Invalid Password(It must be 8-20 characters, must contain digits, one upper case and one lower case alphabet)");
							}
							if (!validGender) {
								System.out.println("Invalid Gender");
							}
						} catch (Exception e) {
							System.err.println("email already exists.. select choice for login");
						}
					} else if (isLogin) {
						System.err.println("user already logged in...");
					}
					break;
				}
				case "3": {
					System.out.println("Enter email");
					String email = sc.readLine().trim();
					System.out.println("Enter the new password");
					String newPwd = sc.readLine();
					try {
						if(userService.savePassword(newPwd, email))
							System.out.println("password changed successfully.....!");
					} catch (Exception e) {
						System.err.println("Please enter your registered Email...");
					}
				}
				
				default: {
					isExit = false;
					sc.close();
					break;
				}
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
	}
	
	public static void afterLogin(String username, String password, boolean isLogin) {
		String choice = null;
		
		while(isLogin) {
			System.out.println("Hi "+ username + "!");
			System.out.println("Select Choice :  ");
			System.out.println("1. Post a tweet");
			System.out.println("2. View My Tweets");
			System.out.println("3. View All Tweets");
			System.out.println("4. View All Users");
			System.out.println("5. Reset Password");
			System.out.println("6. Logout");
			System.out.println("Press any other key to terminate TweetApp...");
			
			BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
			try {
				try {
				choice = sc.readLine().trim();
				}catch(Exception e) {
					System.out.println("Invalid Choice...try again...");
				}
				
			switch(choice) {			
			case "1": {
					System.out.println("Enter tweet message...!");
					try {
						String tweetMessage = sc.readLine().trim();
						if(tweetService.saveTweet(tweetMessage, username))
							System.out.println("Message saved successfully.....!");
						else 
							System.out.println("Something went wrong. Please try again...");
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				}
			case "2": {
				
					try {
						List<Tweet> userTweets = tweetService.getUsertweets(username);
						System.out.println("Your tweets are : ");
						userTweets.forEach(tweet -> {
							System.out.println(tweet.getTweet());
						});
					} catch (Exception e) {
						System.err.println("No tweets found under " + username + "....!");
					}
				
				break;
			}
			case "3": {
				List<Tweet> userTweets = tweetService.getAlltweets();
				System.out.println(" Tweets are : ");
				userTweets.forEach(tweet -> {
					System.out.println(tweet.getTweet());
				});
				break;
			}
			case "4": {
				List<User> userList = userService.getAllUsers();
				System.out.println(" The Users list : ");
				userList.forEach(user -> {
					System.out.println("  " + user.getEmail());
				});
				break;
			}
			case "5": {				
				try {
					System.out.println("Enter email");
					String email = sc.readLine().trim();
					System.out.println("Enter the old password");
					String oldPwd = sc.readLine();
					System.out.println("Enter the new password");
					String newPwd = sc.readLine();
					if(userService.saveNewPassword(oldPwd, newPwd, email))
						System.out.println("password changed successfully.....!");
					
				} catch (Exception e) {
					System.err.println("Please enter your email/old password correctly...");
				}
				break;
			}
			case "6": {				
					username = null;
					isLogin = false;
					System.out.println("Logged out successfully "+ isLogin);
					break;
				}
				
			default: {
				isExit = false;
				sc.close();
				break;
			}
			}
			}catch (IOException e1) {
				e1.printStackTrace();
			}
			} 
			
			}
	
}

