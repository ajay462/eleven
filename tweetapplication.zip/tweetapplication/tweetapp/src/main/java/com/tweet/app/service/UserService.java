package com.tweet.app.service;

import com.tweet.app.model.User;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.tweet.app.dao.UserDaoSqlImpl;
import com.tweet.app.util.DateUtil;


public class UserService {

	UserDaoSqlImpl userDao = new UserDaoSqlImpl();
	
	public boolean validateUser(String email, String password) throws Exception {
		User existedUser = userDao.getUser(email);
		if (existedUser != null) {
			if (existedUser.getPassword().equals(password)) {
				return true;
			} else {
				return false;
			}
		} else {
			throw new Exception();
		}
	}
	
	public List<User> getAllUsers() {
		
		return userDao.getAllUsers();
	}
	
	public void saveUser(String fname, String lname, String gender, String dob, String email, String pwd) throws Exception {
		User newUser = new User(fname, lname, gender, DateUtil.convertToDate(dob), email, pwd);
		userDao.saveUser(newUser);
	}
	
	public boolean savePassword(String newPwd, String username) throws Exception {
		User existedUser = userDao.getUser(username);		
		if(existedUser != null) {				
			
			return userDao.savePassword(newPwd, username);
		} else {
			throw new Exception();
		}
	}
	
	public boolean saveNewPassword(String oldPwd, String newPwd, String username) throws Exception {
		User existedUser = userDao.getUser(username);		
		if(existedUser != null && existedUser.getPassword().equals(oldPwd)) {				
			
			return userDao.savePassword(newPwd, username);
		} else {
			throw new Exception();
		}
	}
		
		public boolean isValidPassword(String password) {

			String regex = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$";

			Pattern p = Pattern.compile(regex);
			if (password == null) {
				return false;
			}
			Matcher m = p.matcher(password);
			return m.matches();
		}

		public boolean isValidEmail(String email) {
			String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
			Pattern pattern = Pattern.compile(regex);
			Matcher m = pattern.matcher(email);
			return m.matches();

		}

		public boolean isValidDateOfBirth(String dob) {
			String regex = "^(?:[0-9]{2})?[0-9]{2}/[0-3]?[0-9]/[0-3]?[0-9]$";
			Pattern pattern = Pattern.compile(regex);
			Matcher m = pattern.matcher(dob);
			return m.matches();
		}

		public boolean isValidName(String name) {

			String regex = "^[A-Za-z]\\w{5,29}$";
			Pattern p = Pattern.compile(regex);
			if (name == null) {
				return false;
			}
			Matcher m = p.matcher(name);
			return m.matches();
		}

	}	
