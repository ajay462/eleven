create database tweet;

use tweet;

drop table user;
CREATE TABLE user(
us_f_name varchar(60) not null,
us_l_name varchar(60) ,
us_gender varchar(60) not null,
us_dob date null,
us_email varchar(60),
us_password varchar(60) not null,
primary key(us_email));

create table post(
id int auto_increment,
message varchar(256) not null,
us_email varchar(60),
date_of_post timestamp DEFAULT CURRENT_TIMESTAMP, 
primary key(id,us_email),
constraint user_tweet_fk foreign key (us_email)
references user (us_email) on delete cascade );


INSERT INTO user  (`us_f_name`, `us_l_name`, `us_gender`, `us_dob`, `us_email`, `us_password`)
 VALUES ('abc', 'abc', 'Male', '1999-03-19', 'abc@gmail.com', '123456');
 
INSERT INTO user  (`us_f_name`, `us_l_name`, `us_gender`, `us_dob`, `us_email`, `us_password`)
 VALUES ('xyz', 'xyz', 'Male', '1999-03-19', 'xyz@gmail.com', '123456');
 
 
 INSERT INTO post(message,us_email)values('roses are red...','abc@gmail.com');
 
 INSERT INTO post(message,us_email)values('sky is blue...','xyz@gmail.com');
