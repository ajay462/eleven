INSERT INTO user  (`us_first_name`, `us_last_name`, `us_gender`, `us_dob`, `us_email`, `us_password`)
 VALUES ('bob', 'bob', 'Male', '2000-08-25', 'bob@gmail.com', 'bob54321');
 
INSERT INTO user  (`us_first_name`, `us_last_name`, `us_gender`, `us_dob`, `us_email`, `us_password`)
 VALUES ('alice', 'alice', 'Female', '1997-03-17', 'alice@gmail.com', 'alice54321');
 
 
 INSERT INTO post(po_message,us_email)values('Earth is round...','bob@gmail.com');
 
 INSERT INTO post(po_message,us_email)values('sky is blue...','alice@gmail.com');
 
 select * from user;
 
 select * from post;