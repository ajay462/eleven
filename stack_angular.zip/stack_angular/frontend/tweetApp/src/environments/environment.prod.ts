export const environment = {
  production: true,
  baseUrl:"http://localhost:8050/api/v1.0/tweets/"
};
